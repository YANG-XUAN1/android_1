package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;
import com.example.memo.UTIL.DataUtil;
import android.os.Bundle;
import android.widget.TextView;

import com.example.memo.R;

public class TargetActivity extends AppCompatActivity {
    TextView time ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_target);

        time = findViewById(R.id.Target_time);
        time.setText(DataUtil.getNowDateTime());

    }
}
