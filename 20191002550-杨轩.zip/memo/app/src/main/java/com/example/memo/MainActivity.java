package com.example.memo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.example.memo.UTIL.MySQLite;
import com.example.memo.activity.LoginActivity;
import com.example.memo.activity.RegisterActivity;

public class MainActivity extends AppCompatActivity {
    private Button btnLogin;
    private Button btnRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        MySQLite db = new MySQLite(this,"Usersql",null,1);
//        db.deleteDatabase(this,"Usersql");

        btnLogin = findViewById(R.id.btn_login );
        btnLogin.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent in = new Intent();
                in.setClass(MainActivity.this, LoginActivity.class);
                startActivity(in);
                finish();
            }
        });

        btnRegister = findViewById(R.id.btn_register );
        btnRegister.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent in = new Intent();
                in.setClass(MainActivity.this, RegisterActivity.class);
                startActivity(in);
                finish();
            }
        });
    }
}
