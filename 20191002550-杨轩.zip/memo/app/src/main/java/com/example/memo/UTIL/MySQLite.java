package com.example.memo.UTIL;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MySQLite extends SQLiteOpenHelper {
    public MySQLite(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql = "create table logins(id integer primary key,usname text,uspwd text)";
        db.execSQL(sql);
        String sql2 = "create table commiss(aid integer primary key,address text,leavetime text,arrivetime text,summary text)";
        db.execSQL(sql2);
        String sql3 = "create table diary(aid integer primary key,time text,title text,content text)";
        db.execSQL(sql3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        System.out.println("更新数据库版本为:" + newVersion);
    }

    public boolean deleteDatabase(Context context,String NAME){
        return context.deleteDatabase(NAME);
    }
}
