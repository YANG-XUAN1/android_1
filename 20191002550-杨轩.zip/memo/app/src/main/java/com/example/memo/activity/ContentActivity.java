package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import com.example.memo.R;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class ContentActivity extends AppCompatActivity {
    private Button button ,button2;
    private TextView textView;
    SharedPreferences sp1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        sp1 = this.getSharedPreferences("diaryid",this.MODE_PRIVATE);
        textView = findViewById(R.id.dia);
        textView.setText(sp1.getString("id",null));
        button = findViewById(R.id.returns);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
