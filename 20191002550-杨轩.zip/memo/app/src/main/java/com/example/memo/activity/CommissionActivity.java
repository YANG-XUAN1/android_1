package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.memo.R;
import com.example.memo.UTIL.MySQLite;

public class CommissionActivity extends AppCompatActivity {

    private EditText address,leave,arrive,summary;
    private Button btngo;
    MySQLite sqlite2;
    SQLiteDatabase db1;
    SharedPreferences sp1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commission);

        address = findViewById(R.id.address);
        leave = findViewById(R.id.leavetime);
        arrive = findViewById(R.id.arrivetime);
        summary = findViewById(R.id.summary);

        sqlite2 = new MySQLite(this,"USER",null,1);
        db1 = sqlite2.getWritableDatabase();
        sp1 = this.getSharedPreferences("comis",this.MODE_PRIVATE);


        btngo = findViewById(R.id.depart);
        btngo.setOnClickListener(new View.OnClickListener() {
            boolean flag = true;
            @Override
            public void onClick(View view) {
                String ar = address.getText().toString().trim();
                String lv = leave.getText().toString().trim();
                String ai = arrive.getText().toString().trim();
                String su = summary.getText().toString().trim();

                if(ar.length()==0||lv.length() == 0){
                    Toast.makeText(CommissionActivity.this,"到达地址/出发时间不能为空",Toast.LENGTH_SHORT).show();
                }
                else{
                    if(ai.equals(lv)){
                        Log.d("a",ai);
                        Toast.makeText(CommissionActivity.this, "到达时间不能和出发时间一样", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        ContentValues cv1 = new ContentValues();
                        cv1.put("address",ar);
                        cv1.put("leavetime",lv);
                        cv1.put("arrivetime",ai);
                        cv1.put("summary",su);
                        db1.insert("commiss",null,cv1);
                        cv1.clear();
                        db1.close();
                        sqlite2.close();
                        SharedPreferences.Editor editor = sp1.edit();
                        editor.putString("address",ar);
                        editor.putString("leavetime",lv);
                        editor.putString("arrivetime",ai);
                        editor.putString("summary",su);
                        editor.commit();
                        Toast.makeText(CommissionActivity.this,"添加成功",Toast.LENGTH_SHORT).show();
                        finish();

                    }
                }
            }
        });




    }
}
