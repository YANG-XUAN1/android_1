package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.content.Intent;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import com.example.memo.UTIL.MySQLite;
import android.util.Log;
import com.example.memo.R;
import java.util.ArrayList;
import android.util.DisplayMetrics;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class DiaryActivity extends AppCompatActivity {
    MySQLite sql_dia;
    Button btn_add;
    LinearLayout Li_diary;
    SQLiteDatabase sqLiteDatabase;
    ArrayList<String> diaryList = new ArrayList<String>();
    private int num;
    private String s;
    ArrayList<String> contentList = new ArrayList<String>();
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary);

        sp = this.getSharedPreferences("diaryid",this.MODE_PRIVATE);

        sql_dia = new MySQLite(this,"USER",null,1);
        sqLiteDatabase = sql_dia.getReadableDatabase();

        Cursor cursor2 = sqLiteDatabase.query("diary",null,null,null,null,null,null);

        while(cursor2.moveToNext()){
            Log.d("a",cursor2.getString(1));
            String time = cursor2.getString(1);
            String title = cursor2.getString(2);
            String diary = "时间："+time+ "\n" + title ;
            diaryList.add(diary);
            String content = cursor2.getString(3);
            contentList.add(content);
        }
        cursor2.close();
        sqLiteDatabase.close();
        sql_dia.close();

        //获取屏幕大小，以合理设定按钮大小及位置
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;

        Li_diary = findViewById(R.id.diary);
        //设置显示阈值
        if (diaryList.size()<=7){
            num = diaryList.size();
        } else num = 7;

        Button Btn[] = new Button[num];
        int j = -1;
        for  (int i=0; i<=num-1; i++) {
            Btn[i]=new Button(this);
            Btn[i].setId(2000+i);
            Btn[i].setText(diaryList.get(i));
            Btn[i].setBackground(getResources().getDrawable(R.drawable.feedback));
            RelativeLayout.LayoutParams btParams = new RelativeLayout.LayoutParams (width-50,100);  //设置按钮的宽度和高度
            if (i%2 == 0) {
                j++;
            }
            btParams.leftMargin = 25;
            btParams.topMargin = 20 + 205*j;   //纵坐标定位

            Li_diary.addView(Btn[i],btParams);   //将按钮放入layout组件
        }


        btn_add = findViewById(R.id.add_diary);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in =new Intent(DiaryActivity.this,WriteDiaryActivity.class);
                startActivity(in);
            }
        });

        for (int i=0;i<num;i++){
            s = contentList.get(i);

            Btn[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("id",s);
                    editor.commit();
                    Intent in = new Intent(DiaryActivity.this,ContentActivity.class);
                    startActivity(in);
                }
            });
        }


    }
}
