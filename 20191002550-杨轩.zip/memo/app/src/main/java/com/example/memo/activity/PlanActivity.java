package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.memo.R;

public class PlanActivity extends AppCompatActivity {
    private Button btnmain;
    private Button btnmy;
    SharedPreferences sp3;
    private TextView address1,leave1,arrive1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan);

        address1 = findViewById(R.id.com_address);
        leave1 = findViewById(R.id.com_leavetime);
        arrive1 = findViewById(R.id.com_arrivetime);
        sp3 = this.getSharedPreferences("comis",this.MODE_PRIVATE);

        address1.setText(sp3.getString("address",null));
        leave1.setText(sp3.getString("leavetime",null));
        arrive1.setText(sp3.getString("arrivetime",null));

        btnmain=findViewById(R.id.main1);
        btnmain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(PlanActivity.this, HomeActivity.class);
                startActivity(in);
                finish();
            }
        });

        btnmy=findViewById(R.id.myself1);
        btnmy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(PlanActivity.this, MyselfActivity.class);
                startActivity(in);
                finish();
            }
        });

    }
}
