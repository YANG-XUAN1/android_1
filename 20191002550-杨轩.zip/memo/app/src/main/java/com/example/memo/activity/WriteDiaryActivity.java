package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;
import com.example.memo.R;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.memo.UTIL.diary_sql;
import com.example.memo.UTIL.DataUtil;

public class WriteDiaryActivity extends AppCompatActivity {
    private TextView time,title;
    private Button save;
    private EditText content;
    diary_sql sql_dia1;
    SQLiteDatabase sqLiteDatabase1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_diary);

        sql_dia1 = new diary_sql(this,"USER",null,1);
        sqLiteDatabase1 = sql_dia1.getWritableDatabase();

        time = findViewById(R.id.current_time);
        final String str = DataUtil.getNowDateTime();
        time.setText(str);

        title = findViewById(R.id.title_dia);
        content = findViewById(R.id.content_dia);
        save = findViewById(R.id.save);
        save.setOnClickListener(new View.OnClickListener() {
            boolean flag =true;
            @Override
            public void onClick(View view) {
                String cont = content.getText().toString();
                String tit = title.getText().toString();
                if(tit.equals("")){
                    Toast.makeText(WriteDiaryActivity.this,"标题不能为空",Toast.LENGTH_SHORT).show();
                }
                else {
                    Cursor cursor = sqLiteDatabase1.query("diary",new String[]{"time"},null,null,null,null,null);

                    while(cursor.moveToNext()){
                        if(cursor.getString(0).equals(str)){
                            flag = false;
                            break;
                        }
                    }
                    cursor.close();

                    if(flag){
                        ContentValues cv = new ContentValues();
                        cv.put("time",str);
                        cv.put("title",tit);
                        cv.put("content",cont);
                        sqLiteDatabase1.insert("diary",null,cv);
                        cv.clear();
                        sqLiteDatabase1.close();
                        sql_dia1.close();

                        Toast.makeText(WriteDiaryActivity.this,"记录完成",Toast.LENGTH_SHORT).show();
                        WriteDiaryActivity.this.finish();
                    }
                    else {
                        Toast.makeText(WriteDiaryActivity.this,"已有该天日记！！",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
