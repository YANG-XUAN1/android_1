package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.LayoutDirection;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.memo.UTIL.MySQLite;
import android.util.Log;
import java.util.ArrayList;
import android.util.DisplayMetrics;
import android.widget.RelativeLayout;

import com.example.memo.R;
public class commissionsActivity extends AppCompatActivity {
    private Button btnadd;
    SQLiteDatabase db2;
    MySQLite sqlite2;
    LinearLayout commiss;
    private int num;
    private TextView view;
    private ArrayList<String> commissions = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commissions);
        sqlite2 = new MySQLite(this,"USER",null,1);
        db2 = sqlite2.getReadableDatabase();

        Cursor cursor1 = db2.query("commiss",null,null,null,null,null,null);

        while (cursor1.moveToNext()){
            String location = cursor1.getString(1);
            String leave = cursor1.getString(2);
            String arrive = cursor1.getString(3);
//            String str = location + "   " + leave+"   "+arrive ;
            commissions.add(location);
            commissions.add(leave);
            commissions.add(arrive);
        }
        cursor1.close();
        db2.close();
        sqlite2.close();

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int high = dm.heightPixels;


        commiss = findViewById(R.id.commissions);
        //设置显示阈值
        if (commissions.size()<=21){
            num = commissions.size();
        } else num = 21;

        TextView textViews[] = new TextView[num*3];
        LinearLayout layout[] = new LinearLayout[num];
        for  (int i=0; i<=num/3-1; i++) {
            layout[i]=new LinearLayout(this);
            for  (int t=0; t<3; t++){
                int text = 3*i + t;
                textViews[text]=new TextView(this);
//            comm[i].setId(2000+i);
                textViews[text].setText(commissions.get(text));
                textViews[text].setBackground(getResources().getDrawable(R.drawable.diaryview));
                RelativeLayout.LayoutParams textparams = new RelativeLayout.LayoutParams(220,40);
                textparams.leftMargin = 10;
                layout[i].addView(textViews[text],textparams);
            }
            RelativeLayout.LayoutParams btParams = new RelativeLayout.LayoutParams(width-10,40);
//            btParams.leftMargin = 10+ ((width-50)/2+10)*(i%2);   //横坐标定位
            btParams.leftMargin = 5;
            btParams.topMargin = 20;   //纵坐标定位
            commiss.addView(layout[i],btParams);   //将按钮放入layout组件
        }


        btnadd = findViewById(R.id.add_commission);
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(commissionsActivity.this,CommissionActivity.class);
                startActivity(in);
            }
        });
    }
}
