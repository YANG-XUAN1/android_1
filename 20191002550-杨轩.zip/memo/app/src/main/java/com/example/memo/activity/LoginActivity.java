package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.accounts.Account;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.memo.UTIL.Stringutils;
import com.example.memo.UTIL.Toastutils;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.memo.R;
import com.example.memo.UTIL.MySQLite;

public class LoginActivity extends AppCompatActivity {
//    private SharedPreferences loginPreference;
//    private CheckBox remember;
    MySQLite mysql;
    SQLiteDatabase db;
    SharedPreferences sp1,sp2;

    private EditText etAcount;
    private EditText etPwd;
    private Button Login;
    private Button btnreg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etAcount = findViewById(R.id.et_account);
        etPwd =findViewById(R.id.et_pwd);
        Login = findViewById(R.id.btn_login2);

        sp1 = this.getSharedPreferences("useinfo",this.MODE_PRIVATE);
        sp2 = this.getSharedPreferences("username",this.MODE_PRIVATE);


        etAcount.setText(sp1.getString("usname",null));
        etPwd.setText(sp1.getString("uspwd",null));
        mysql = new MySQLite(this,"USER",null,1);      //建数据库或者取数据库
        db = mysql.getReadableDatabase();

//        loginPreference = getSharedPreferences("login", MODE_PRIVATE);
//        SharedPreferences.Editor editor = loginPreference.edit();
//        boolean cheched = loginPreference.getBoolean("checked", false);
//        if (cheched) {
//            Map<String, Object> m = readLogin();
//            if (m != null) {
//                etAcount.setText((CharSequence) m.get("userName"));
//                etPwd.setText((CharSequence) m.get("password"));
//                remember.setChecked(cheched);
//            }
//        }

        Login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String Account = etAcount.getText().toString().trim();
                String pwd =etPwd.getText().toString().trim();

                Cursor cursor = db.query("logins",new String[]{"usname","uspwd"}," usname=? and uspwd=?",new String[]{Account,pwd},null,null,null);

                int flag = cursor.getCount();                            //查询出来的记录项的条数，若没有该用户则为0条
                if(flag!=0){                                            //若查询出的记录不为0，则进行跳转操作
                    Intent intent = new Intent();
                    intent.setClass(LoginActivity.this,HomeActivity.class);            //设置页面跳转
                    SharedPreferences.Editor editor = sp2.edit();
                    cursor.moveToFirst();                                   //将光标移动到position为0的位置，默认位置为-1
                    String loginname = cursor.getString(0);
                    editor.putString("Loginname",loginname);
                    editor.commit();                                        //将用户名存到SharedPreferences中
                    startActivity(intent);
                }
                else{
                    Toast.makeText(LoginActivity.this,"用户名或密码错误！",Toast.LENGTH_LONG).show();             //提示用户信息错误或没有账号
                }
                cursor.close();
                db.close();
                finish();

//                Intent in = new Intent(LoginActivity.this, HomeActivity.class);
//                startActivity(in);
//                configLoginInfo(remember.isChecked());
            }
        });

        btnreg=findViewById(R.id.reg);
        btnreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(in);
                finish();
            }
        });

    }

//    private void login(String Account , String Pwd){
//        if(Stringutils.isEmpty(Account) ){
//            Toast.makeText(this,"请输入账号",Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if(Stringutils.isEmpty(Pwd) ){
//            Toast.makeText(this,"请输入密码",Toast.LENGTH_SHORT).show();
//            return;
//        }
//    }

//    public void configLoginInfo(boolean checked) {
//        SharedPreferences.Editor editor = loginPreference.edit();
//        editor.putBoolean("checked", remember.isChecked());
//        if (checked) {
//            editor.putString("userName", etAcount.getText().toString());
//            editor.putString("password", etPwd.getText().toString());
//        } else {
//            editor.remove("userName").remove("password");
//        }
//        editor.commit();
//    }
//
//    public Map<String, Object> readLogin() {
//        Map<String, Object> m = new HashMap<>();
//        String userName = loginPreference.getString("userName", "");
//        String password = loginPreference.getString("password", "");
//        m.put("userName", userName);
//        m.put("password", password);
//        return m;
//    }

//    public void onClick(View v) {
//        //当点击登录按钮时，获取QQ账号和密码
//        String name = etAcount.getText().toString().trim();
//        String password = etPwd.getText().toString();
//
//        // 检验账号和密码是否为空
//
//        if(Stringutils.isEmpty(name)){
//            Toast.makeText(this, "请输入QQ账号", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        if(Stringutils.isEmpty(password)){
//            Toast.makeText(this, "请输入密码", Toast.LENGTH_SHORT).show();
//
//            return;
//        }
//    // 登录成功
//        Toast.makeText(this, "登陆成功", Toast.LENGTH_SHORT).show();
//
//    //保存用户信息
//        boolean saveSuccess = com.example.memo.UTIL.password.saveUserInfo(this, name, password);
//
//        if (!saveSuccess){
//            Toast.makeText(this, "保存失败", Toast.LENGTH_SHORT).show();
//        }
//    }
}
