package com.example.memo.UTIL;

public class DiaryUtils {
    private String _id;
    private String time;
    private String title;
    private String content;
    public String get_id() {
        return _id;
    }
    public void set_id(String _id) {
        this._id = _id;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    @Override
    public String toString() {
        return time + ", " + title + ", " + content;
    }
    public DiaryUtils(String _id, String time, String title, String content) {
        super();
        this._id = _id;
        this.time = time;
        this.title = title;
        this.content = content;
    }

}
