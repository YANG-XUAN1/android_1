package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.memo.R;

public class HomeActivity extends AppCompatActivity {
    private Button btncommission;
    private Button btndiary;
    private Button btnaccount;
    private Button btntarget;
    private Button btnmain;
    private Button btnmy;
    private Button btnplan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btncommission = findViewById(R.id.daiban);
        btncommission.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent in = new Intent();
                in.setClass(HomeActivity.this,commissionsActivity.class);
                startActivity(in);
            }
        });

        btndiary = findViewById(R.id.riji);
        btndiary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(HomeActivity.this,DiaryActivity.class);
                startActivity(in);
            }
        });

        btnaccount = findViewById(R.id.jizhang);
        btnaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(HomeActivity.this,AccountActivity.class);
                startActivity(in);
            }
        });

        btntarget = findViewById(R.id.daka);
        btntarget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(HomeActivity.this,TargetActivity.class);
                startActivity(in);
            }
        });

        btnmy=findViewById(R.id.myself);
        btnmy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(HomeActivity.this, MyselfActivity.class);
                startActivity(in);
            }
        });

        btnplan=findViewById(R.id.plan);
        btnplan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(HomeActivity.this, PlanActivity.class);
                startActivity(in);
            }
        });
    }
}
