package com.example.memo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.memo.R;
import com.example.memo.myself_center.HelpActivity;
import com.example.memo.myself_center.ManagerActivity;
import com.example.memo.myself_center.MessageActivity;
import com.example.memo.myself_center.PersonalActivity;
import com.example.memo.myself_center.SettingActivity;

import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.widget.TextView;


public class MyselfActivity extends AppCompatActivity {
    private Button btnmain;
    private Button btnmy;
    private Button btnplan;
    private Button manager,help,message,setting;
//    private Button takephoto;
//    final int TAKE_PHOTO=1;
    private ImageView iv_photo;
    private SharedPreferences sp,sp2;
    private TextView nick;
//    Uri imageUri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myself);

        manager = findViewById(R.id.manager);
        help = findViewById(R.id.helper);
        message = findViewById(R.id.My_message);
        setting = findViewById(R.id.setting);

        sp = this.getSharedPreferences("imageurl",this.MODE_PRIVATE);
        String imagepath = sp.getString("url",null);
        iv_photo =findViewById(R.id.img_photo);
        if(imagepath!=null){
            Bitmap bitmap=BitmapFactory.decodeFile(imagepath);
            iv_photo.setImageBitmap(bitmap);//将图片放置在控件上
        }

        sp2 = this.getSharedPreferences("Personal",this.MODE_PRIVATE);
        nick =findViewById(R.id.nickname);
        nick.setText(sp2.getString("nickname",null));

        btnmy = findViewById(R.id.click);
        btnmy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MyselfActivity.this, PersonalActivity.class);
                startActivity(in);
            }
        });


        manager.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(MyselfActivity.this, ManagerActivity.class);
                startActivity(in);
            }
        });

        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(MyselfActivity.this, HelpActivity.class);
                startActivity(in);
            }
        });

        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(MyselfActivity.this, MessageActivity.class);
                startActivity(in);
            }
        });

        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(MyselfActivity.this, SettingActivity.class);
                startActivity(in);
            }
        });

        btnmain=findViewById(R.id.main2);
        btnmain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(MyselfActivity.this, HomeActivity.class);
                startActivity(in);
                finish();
            }
        });

        btnplan=findViewById(R.id.plan2);
        btnplan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                in.setClass(MyselfActivity.this, PlanActivity.class);
                startActivity(in);
                finish();
            }
        });
    }

//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        switch (requestCode)
//        {
//            case TAKE_PHOTO:
//                if(resultCode==RESULT_OK)
//                {
//                    try
//                    {
//                        Bitmap bitmap= BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
//                        iv_photo.setImageBitmap(bitmap);
//                        //将图片解析成Bitmap对象，并把它显现出来
//                    }
//                    catch (FileNotFoundException e)
//                    {
//                        e.printStackTrace();
//                    }
//                }
//                break;
//            default:
//                break;
//        }
//    }

}
