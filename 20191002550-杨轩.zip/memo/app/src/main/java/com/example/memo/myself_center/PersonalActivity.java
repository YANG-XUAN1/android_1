package com.example.memo.myself_center;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.TextView;

import com.example.memo.R;

public class PersonalActivity extends AppCompatActivity {
    private EditText nickname,gender ,profession,mailbox,birthday,resume;
    private Button btn_photo ;
    CheckBox checkBox;
    private SharedPreferences sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal);

        btn_photo = findViewById(R.id.head_photo);
        btn_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(PersonalActivity.this,photoActivity.class);
                startActivity(in);
                finish();
            }
        });

        sp = this.getSharedPreferences("Personal",this.MODE_PRIVATE);

        nickname = findViewById(R.id.edit_nickname);
        gender =findViewById(R.id.sex);
        profession =findViewById(R.id.profession);
        mailbox=findViewById(R.id.mailbox);
        birthday=findViewById(R.id.birthday);
        resume=findViewById(R.id.resume);
        nickname.setText(sp.getString("nickname",null));
        gender .setText(sp.getString("gender",null));
        profession.setText(sp.getString("procession",null));
        mailbox.setText(sp.getString("mailbox",null));
        birthday.setText(sp.getString("birthday",null));
        resume.setText(sp.getString("resume",null));

        nickname.setEnabled(false);
        gender.setEnabled(false);
        profession.setEnabled(false);
        mailbox.setEnabled(false);
        birthday.setEnabled(false);
        resume.setEnabled(false);



        checkBox = findViewById(R.id.editor);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    nickname.setEnabled(true);
                    nickname.setClickable(true);
                    gender.setEnabled(true);
                    gender.setClickable(true);
                    profession.setEnabled(true);
                    profession.setClickable(true);
                    mailbox.setEnabled(true);
                    mailbox.setClickable(true);
                    birthday.setEnabled(true);
                    birthday.setClickable(true);
                    resume.setEnabled(true);
                    resume.setClickable(true);
                    String nick = nickname.getText().toString();
                    String gen = gender.getText().toString();
                    String pro = profession.getText().toString();
                    String mail = mailbox.getText().toString();
                    String bir = birthday.getText().toString();
                    String res = resume.getText().toString();

                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("nickname",nick);
                    editor.putString("gender",gen);
                    editor.putString("procession",pro);
                    editor.putString("mailbox",mail);
                    editor.putString("birthday",bir);
                    editor.putString("resume",res);
                    editor.commit();
                }
                else {
                    nickname.setEnabled(false);
                    nickname.setClickable(false);
                    gender.setEnabled(false);
                    gender.setClickable(false);
                    profession.setEnabled(false);
                    profession.setClickable(false);
                    mailbox.setEnabled(false);
                    mailbox.setClickable(false);
                    birthday.setEnabled(false);
                    birthday.setClickable(false);
                    resume.setEnabled(false);
                    resume.setClickable(false);
                }
            }
        });

    }
}
