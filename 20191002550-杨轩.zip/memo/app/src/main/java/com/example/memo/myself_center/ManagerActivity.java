package com.example.memo.myself_center;

import androidx.appcompat.app.AppCompatActivity;
import com.example.memo.R;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;

public class ManagerActivity extends AppCompatActivity {
    private Switch commssion,diary,target,account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);

        commssion = findViewById(R.id.open_commission);
        diary = findViewById(R.id.open_diary);
        target = findViewById(R.id.open_target);
        account = findViewById(R.id.open_account);

        commssion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(commssion.isChecked() ){
                    Toast.makeText(ManagerActivity.this,"打开：待办事项",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(ManagerActivity.this,"关闭‘待办事项’",Toast.LENGTH_SHORT).show();
                }
            }
        });

        diary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(commssion.isChecked() ){
                    Toast.makeText(ManagerActivity.this,"打开：日记",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(ManagerActivity.this,"关闭‘日记’",Toast.LENGTH_SHORT).show();
                }
            }
        });

        target.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(commssion.isChecked() ){
                    Toast.makeText(ManagerActivity.this,"打开：习惯打卡",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(ManagerActivity.this,"关闭‘习惯打卡’",Toast.LENGTH_SHORT).show();
                }
            }
        });

        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(commssion.isChecked() ){
                    Toast.makeText(ManagerActivity.this,"打开：记账",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(ManagerActivity.this,"关闭‘记账’",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
