package com.example.memo.UTIL;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.app.Dialog;
import android.widget.TextView;

import com.example.memo.R;


public class DialogUtil extends Dialog{
    private Context mContext;
    private TextView textView;
    private Button buttonConfirm;
    private String message;

    private MyOnclickListener mMyOnclickListener;

    public DialogUtil( Context context) {
        super(context);
    }

    public DialogUtil(Context context, int themeResId) {
        super(context, themeResId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diary_popupwindow);
        setCanceledOnTouchOutside(false);
        initView();
    }

    @Override
    public void show() {
        super.show();
        WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
        layoutParams.width= 1040;
        layoutParams.height= 1200;
        layoutParams.gravity = Gravity.TOP | Gravity.LEFT;
        layoutParams.x=100;
        layoutParams.y=100;
        getWindow().getDecorView().setPadding(0, 0, 0, 0);
        getWindow().setAttributes(layoutParams);
    }


    private void initView(){
        textView=findViewById(R.id.content);
        buttonConfirm.setText("自定义dialog");

        buttonConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("测试自定义dialog的按钮点击");
                mMyOnclickListener.onYesClick(message);
            }
        });
    }

    //内部接口
    public interface MyOnclickListener{
        public void onYesClick(String message);
    }
    //set内部接口和String参数
    public void setMyOnclickListener(String message,MyOnclickListener myOnclickListener){
        this.message=message;
        this.mMyOnclickListener=myOnclickListener;
    }

}
